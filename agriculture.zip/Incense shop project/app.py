from flask import Flask, render_template, request, redirect, url_for, flash, session
from mongoengine import Document, StringField, DecimalField, IntField, connect, EmailField, DateTimeField
from pymongo import MongoClient
import os
from werkzeug.utils import secure_filename
from cryptography.fernet import Fernet
from datetime import datetime
from bson import ObjectId


app = Flask(__name__)

app.secret_key = 'your_secret_key'

# Connect to MongoDB
connect('Incense_Shop', host='localhost', port=27017)

client = MongoClient('mongodb://localhost:27017/')
db = client['Incense_Shop']
products_collection = db['products'] 
usr = db['user']
contact_detail = db['contact_details']
order_collection = db['order_detail']

# Configure file upload settings
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif'}
app.secret_key = 'your_secret_key'  # Required for session handling

# Helper function to check allowed file extensions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# MongoEngine model for Product
class Product(Document):
    name = StringField(required=True)
    price = DecimalField(required=True)
    image = StringField(required=True)  # Store relative path to the image
    productFragrance = StringField(required=True)
    incenseType = StringField(required=True)
    packSize = StringField(required=True)
    additionalDetails = StringField(required=True)

class Order(Document):
    customer_name = StringField(required=True)
    contact_number = StringField(required=True)
    email = EmailField(required=True)
    address = StringField(required=True)
    product = StringField(required=True)
    pack_size = StringField(required=True)
    quantity = IntField(required=True)
    special_instructions = StringField()

    # def save_order(self):
    #     self.save() 

    def save_order(self):
        self.save()


class User(Document):
    username = StringField(required=True, unique=True)
    password = StringField(required=True)  # Store encrypted password

key = b'MYgwBE-dXhW0_YgJugWxSpKQJcNZQOr3AahIuXn0u5I='  # Generate a new key for encryption
fernet = Fernet(key)  # Create a cipher suite

def encrypt_password(password):
    return fernet.encrypt(password.encode()).decode()
    

def decrypt_password(encrypted_password):
    return fernet.decrypt(encrypted_password.encode()).decode()

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # Fetch the user from the database using the username
        user = usr.find_one({'username': username})
        
        if user:
            encrypted_password = user['password']
            try:
                decrypted_password = decrypt_password(encrypted_password)
                
                if decrypted_password == password:
                    session['user'] = username
                    flash("Login Successful!", "success")
                    return redirect(url_for('user_home'))
                else:
                    flash("Invalid Password!", "danger")
            except Exception as e:
                flash("An error occurred during decryption. Please try again", "error")
        else:
            flash("Invalid Username!", "danger")

    return render_template('login.html')


@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if username == 'tuleshwar' and password == 'sahu123':
            flash('Login Successful!', 'success')
            return render_template('admin_home.html')
        else:
            flash("Invalid username or password", 'danger')

    return render_template('admin_login.html')
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        # Check if passwords match
        if password != confirm_password:
            flash("Passwords don't match", 'danger')
            return redirect(url_for('register'))

        # Check if the user already exists
        existing_user = usr.find_one({'username': username})
        if existing_user:
            flash("Username already exists", 'danger')
            return redirect(url_for('register'))

        # Encrypt the password before storing it
        encrypted_password = encrypt_password(password)

        # Insert new user into the MongoDB collection using insert_one
        new_user = {
            'username': username,
            'password': encrypted_password
        }

        try:
            usr.insert_one(new_user)  # Insert the user document
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))  # Redirect to login page after registration
        except Exception as e:
            flash(f"An error occurred: {e}", 'danger')
            return redirect(url_for('register'))  # In case of error, stay on the register page

    return render_template('register.html')

@app.route('/admin_home')
def admin_home():
    products = Product.objects()  # Fetch all products from the database
    print("Products fetched: ", products)  # Log the products to the console
    return render_template('admin_home.html', products=products)


@app.route('/ShowProduct')
def ShowProduct():
    # Fetch all products using MongoEngine
    products = Product.objects()  # Fetch all products from the 'Product' collection
    return render_template('ShowProduct.html', products=products)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        # Retrieve form data
        name = request.form.get('name')
        email = request.form.get('email')
        message = request.form.get('message')

        # Check if any field is empty
        if not name or not email or not message:
            flash('Name, Email, and Message are required', 'error')
            return redirect(url_for('contact'))

        # Data to be inserted into MongoDB
        data = {'name': name, 'email': email, 'message': message ,'timestamp': datetime.now()}

        try:
            # Insert the data into MongoDB collection
            contact_detail.insert_one(data)
            flash('Message sent successfully', 'success')
        except Exception as e:
            flash(f'Error sending message: {e}', 'error')  # Display any database errors

        return redirect(url_for('contact'))

    return render_template('contact.html')

@app.route('/comments', methods=['GET'])
def comments():
    try:
        # Retrieve all messages from the MongoDB collection
        messages = list(contact_detail.find())
        
        for message in messages:
            if 'timestamp' in message:
                message['timestamp'] = message['timestamp'].strftime('%Y-%m-%d %H:%M:%S')

        # Pass the messages to the admin template
        return render_template('comments.html', messages=messages)
    except Exception as e:
        flash(f'Error retrieving messages: {e}', 'error')
        return render_template('comments.html', messages=[])

@app.route('/delete_message<message_id>', methods=['POST'])
def delete_message(message_id):
    """
    Route to delete a specific message from the database by its ID.
    """
    try:
        # Delete the message from the MongoDB collection
        contact_detail.delete_one({'_id': ObjectId(message_id)})
        flash('Message deleted successfully', 'success')
    except Exception as e:
        flash(f'Error deleting message: {e}', 'error')

    # Redirect back to the admin dashboard
    return redirect(url_for('comments'))




@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    if request.method == 'POST':
        # Get data from the form
        product_name = request.form.get('productName')
        product_price = request.form.get('productPrice')
        productFragrance = request.form.get('productFragrance')
        incenseType = request.form.get('incenseType')
        packSize = request.form.get('packSize')
        additionalDetails = request.form.get('additionalDetails')

        # Handle file upload
        if 'productImage' not in request.files:
            return 'No file part'
        file = request.files['productImage']

        if file.filename == '':
            return 'No selected file'

        if file and allowed_file(file.filename):
            # Secure and save the file
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)  # Save file to static/uploads
            file.save(file_path)

            # Create a new product instance and save to MongoDB
            new_product = Product(
                name=product_name,
                price=float(product_price),  # Convert price to float
                image=f'uploads/{filename}',  # Store relative path to the image
                productFragrance=productFragrance,
                incenseType=incenseType,
                packSize=packSize,
                additionalDetails=additionalDetails

            )
            new_product.save()

            # Redirect back to the index page after saving
            return redirect(url_for('admin_home'))

    # Render the form page for adding products
    return render_template('add_product.html')


@app.route('/update_product/<product_id>', methods=['GET', 'POST'])
def update_product(product_id):
    # Fetch the product to be updated from the database
    product = Product.objects(id=product_id).first()
    if not product:
        return 'Product not found', 404

    if request.method == 'POST':
        # Get updated data from the form
        updated_price = request.form.get('productPrice')
        updated_fragrance = request.form.get('productFragrance')

        # Update the fields
        if updated_price:
            product.price = float(updated_price)  # Ensure the price is converted to float
        if updated_fragrance:
            product.productFragrance = updated_fragrance

        # Save the updated product back to the database
        product.save()

        # Redirect back to the admin home page after updating
        return redirect(url_for('admin_home'))

    # Render the update form with the current product details pre-filled
    return render_template('update_product.html', product=product)


@app.route('/delete_product/<product_id>', methods=['POST'])
def delete_product(product_id):
    """
    Route to delete a product by its ID.
    """
    try:
        # Find the product by its ID
        product = Product.objects(id=product_id).first()
        if not product:
            return 'Product not found', 404

        # Delete the product from the database
        product.delete()

        # Redirect to the admin home page after successful deletion
        flash('Product deleted successfully', 'success')
    except Exception as e:
        # Handle any errors during deletion
        flash(f'Error deleting product: {e}', 'error')

    return redirect(url_for('admin_home'))



@app.route('/products', methods=['GET'])
def products():
    # Fetch products from the database (example using MongoDB)
    products = Product.objects()  # Replace with your database query method

    # Pass the products to the template
    return render_template('products.html', products=products)


@app.route('/')
def index():
    # Fetch all products using MongoEngine
    products = Product.objects()  # Fetch all products from the 'Product' collection
    return render_template('index.html', products=products)

@app.route('/product_detail/<string:product_id>', methods=['GET'])
def product_detail(product_id):
    product = Product.objects(id=ObjectId(product_id)).first()
    return render_template('product_detail.html', product=product, product_id=product_id)


@app.route('/uproduct_detail/<string:product_id>', methods=['GET'])
def uproduct_detail(product_id):
    product = Product.objects(id=ObjectId(product_id)).first()
    return render_template('uproduct_detail.html', product=product, product_id=product_id)
    

@app.route('/admin_logout')
def admin_logout():
    # Clear the session to log out the user
    session.clear()  # This will remove the admin's session data

    flash('You have been logged out', 'success')  # Optional flash message to inform the admin
    return redirect(url_for('index'))  # Redirect to the admin login page

@app.route('/user_logout')
def user_logout():
    session.pop('user', None)
    return redirect(url_for('index'))

@app.route('/user_home')
def user_home():
    if 'user' in session:
        # Get the username from the session
        username = session['user']
        
        # Fetch the user document from the 'usr' collection
        user = usr.find_one({'username': username})
        
        if user:
            products = Product.objects()  # You might want to filter these products based on user ID
            
            return render_template('user_home.html', username=user['username'], products=products)
        else:
            return redirect(url_for('login'))
    else:
        return redirect(url_for('login'))

@app.route('/order', methods=['GET', 'POST'])
def order():
    if 'user' not in session:
        flash("You must be logged in to place an order.", "danger")
        return redirect(url_for('login'))

    # Fetch the username from the session
    username = session['user']

    if request.method == 'POST':
        # Collect form data
        customer_name = request.form.get('customer_name')
        contact_number = request.form.get('contact_number')
        email = request.form.get('email')
        address = request.form.get('address')
        product = request.form.get('product')
        pack_size = request.form.get('pack_size')
        quantity = request.form.get('quantity')
        special_instructions = request.form.get('instructions', '')
        order_date = datetime.now()  # Automatically store the order date and time

        # Validate required fields
        if not customer_name or not contact_number or not email:
            flash("Please fill in all required fields", "danger")
            return redirect(url_for('order'))

        # Create an order dictionary
        order_data = {
            "username": username,  # Save the username associated with the order
            "customer_name": customer_name,
            "contact_number": contact_number,
            "email": email,
            "address": address,
            "product": product,
            "pack_size": pack_size,
            "quantity": quantity,
            "special_instructions": special_instructions,
            "order_date": order_date
        }

        # Insert the order into MongoDB
        try:
            order_collection.insert_one(order_data)  # Use the MongoDB collection here
            flash("Your order has been successfully placed!", "success")
            return redirect(url_for('order_success'))
        except Exception as e:
            flash(f"An error occurred while saving your order: {e}", "danger")
            return redirect(url_for('order'))

    # Render the order form
    return render_template('order.html', username=username)

from datetime import datetime

@app.route('/user_order', methods=['GET'])
def user_order():
    # Fetch all orders from the MongoDB collection
    orders = list(order_collection.find())  # Fetch all orders from the order collection

    # Render the user_order template with the fetched orders
    return render_template('user_order.html', orders=orders)


@app.route('/success/<order_id>')
def success(order_id):
    # Fetch the order details from MongoDB
    order = order_collection.find_one({"_id": order_id})
    if not order:
        return "Order not found!", 404

    # Render success page with order details
    return render_template('success.html', order=order, order_id=order_id)

@app.route('/order_success')
def order_success():
    return render_template('order_success.html')

if __name__ == "__main__":
    # Ensure the upload folder exists
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])
    
    # Start Flask app
    app.run(debug=True)
